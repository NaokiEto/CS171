This is for the Interpolating Keyframes Lab 

ANIMATION CONTROLS
To play the animation, press 'P' or 'p'
To pause the animation, press 'S' or 's'
To toggle the animation, press 'T' or 't'
To go to a particular frame, press 'J' or 'j' and then input the frame number you would like
To go to the very first frame, press '0'

CAMERA CONTROLS
To have the camera zoom in, press the up arrow
To have the camera zoom out, press the down arrow
To have the camera rotate left around the origin (0, 0, 0), press the left arrow
To have the camera rotate right around the origin (0, 0, 0), press the right arrow


The default/initial conditions of the animations is that it is paused and will only do one run.

so, for example, to loop forever, press 't'

To run the program, just do python keyframe.py sample.script

As usual, make sure that pyparsing and numpy are installed as discussed in previous READMEs

************************************************************************************************
If additional information is needed to help run the program, please email me at neto@caltech.edu,
and I will gladly assist.
************************************************************************************************
