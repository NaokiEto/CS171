OpenGL Texturing

To run the program, run

python oglTexRenderer.py 500 500 cube.iv

where the first two command line arguments are the size of the window,
width by height in terms of pixels.

The third command line argument is the .iv file.

You can rotate the object. To rotate, press the left mouse button.

As in the other labs, to quit the window, you can press 'q'

************************************************************************************************

If additional information is needed to help run the program, please email me at neto@caltech.edu,

and I will gladly assist.

************************************************************************************************


